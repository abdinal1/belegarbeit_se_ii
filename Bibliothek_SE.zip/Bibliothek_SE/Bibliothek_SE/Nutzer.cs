﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliothek_SE
{
    class Nutzer        //get und set der jeweiligen Attribute der Klasse Nutzer setzen
    {
        public string Nutzer_ID { get; private set; }
        public string Nachname { get; private set; }
        public string Vorname { get; private set; }
    }
}
