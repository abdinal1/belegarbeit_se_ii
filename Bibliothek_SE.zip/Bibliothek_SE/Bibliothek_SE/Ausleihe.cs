﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliothek_SE
{
    class Ausleihe      //get und set der jeweiligen Attribute der Klasse Ausleihe setzen
    {
        public string Ausleihe_ID { get; private set; }
        public DateTime Datum { get; private set; }            //Nutzung des strukturierten Datentypes "DateTime"
    }
}
